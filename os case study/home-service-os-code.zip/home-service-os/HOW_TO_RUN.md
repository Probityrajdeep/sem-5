# How to run: Home Service Booking Management System (OS case study)

## Files

| File | What it shows |
|---|---|
| `src/multithreading.c` | 5 customers served sequentially vs one thread per customer |
| `src/scheduling.c` | FCFS and Round Robin (quantum 2): waiting time, turnaround time, Gantt chart |
| `src/sync.c` | Race condition, fix with a mutex, counting semaphore (3 plumbers) |
| `src/bankers.c` | Banker's algorithm: safe state, safe sequence, request granted / denied |
| `src/memory.c` | First Fit and Best Fit memory allocation |
| `Makefile` | Builds and runs all five programs |

## Requirements

Linux (or WSL on Windows, or macOS) with `gcc` and `make`.
On Ubuntu / WSL: `sudo apt install build-essential`

## Build and run

```
cd home-service-os
make                 # builds all 5 programs
```

Run any one program:

```
./multithreading
./scheduling
./sync
./bankers
./memory
```

Run all five and save their output to `output/`:

```
make run
```

Remove the compiled programs:

```
make clean
```

## Without make

Compile one program directly (the `-pthread` flag is needed for the thread programs):

```
gcc -Wall -pthread -o sync src/sync.c
./sync
```

## Notes

- Times in `multithreading` and `sync` are real measurements, so the exact milliseconds and the order of lines change slightly from run to run.
- `scheduling`, `bankers` and `memory` always print the same results.
- On macOS, unnamed semaphores (`sem_init`) are not supported, so `sync` part 3 will not work there; use Linux or WSL.
