/*
 * Module 5: Memory Management - First Fit and Best Fit
 * Memory blocks (KB) are given to service-processing tasks.
 * When a task is placed in a block, the rest of the block stays free
 * and can be used by later tasks.
 */
#include <stdio.h>

#define NB 5
#define NT 5

int block_size[NB] = {100, 500, 200, 300, 600};
int task_size[NT]  = {212, 417, 112, 426, 150};
const char *task_name[NT] = {"Electrician booking", "Plumber dispatch", "Cleaner scheduling",
                             "Appliance diagnostics", "Payment processing"};

void allocate(int best_fit)
{
    int free_space[NB];
    for (int b = 0; b < NB; b++) free_space[b] = block_size[b];

    printf("\n%s\n", best_fit ? "BEST FIT" : "FIRST FIT");
    printf("Task                     Size   Block\n");
    for (int t = 0; t < NT; t++) {
        int chosen = -1;
        for (int b = 0; b < NB; b++) {
            if (free_space[b] < task_size[t]) continue;      /* too small */
            if (!best_fit) { chosen = b; break; }            /* first one that fits */
            if (chosen == -1 || free_space[b] < free_space[chosen])
                chosen = b;                                  /* smallest one that fits */
        }
        if (chosen == -1) {
            printf("%-24s %4d   Not allocated\n", task_name[t], task_size[t]);
        } else {
            free_space[chosen] -= task_size[t];
            printf("%-24s %4d   Block %d (%d KB), %d KB left\n", task_name[t], task_size[t],
                   chosen + 1, block_size[chosen], free_space[chosen]);
        }
    }

    int total = 0, largest = 0;
    for (int b = 0; b < NB; b++) {
        total += free_space[b];
        if (free_space[b] > largest) largest = free_space[b];
    }
    printf("Free memory left: %d KB, largest free hole: %d KB\n", total, largest);
}

int main(void)
{
    printf("Blocks (KB): 100 500 200 300 600\n");
    allocate(0);
    allocate(1);
    return 0;
}
