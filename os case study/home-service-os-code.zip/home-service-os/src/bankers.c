/*
 * Module 4: Banker's Algorithm
 * Resources = service providers on duty: E (electricians), P (plumbers),
 *             C (cleaners), T (appliance technicians).
 * Processes = 5 booking jobs B0..B4.
 *   Need = Max - Allocation
 * The state is SAFE if all jobs can finish in some order.
 */
#include <stdio.h>

#define N 5   /* jobs */
#define M 4   /* resource types */

int alloc[N][M] = {{0, 1, 0, 1}, {2, 0, 0, 1}, {3, 0, 2, 0}, {2, 1, 1, 1}, {0, 0, 2, 1}};
int max[N][M]   = {{7, 5, 3, 2}, {3, 2, 2, 2}, {9, 0, 2, 2}, {2, 2, 2, 2}, {4, 3, 3, 3}};
int avail[M]    = {3, 3, 2, 2};
int need[N][M];

int is_safe(void)
{
    int work[M], finish[N] = {0}, seq[N], count = 0;
    for (int j = 0; j < M; j++) work[j] = avail[j];

    while (count < N) {
        int found = 0;
        for (int i = 0; i < N; i++) {
            if (finish[i]) continue;
            int ok = 1;
            for (int j = 0; j < M; j++)
                if (need[i][j] > work[j]) ok = 0;
            if (ok) {                              /* job i can finish */
                for (int j = 0; j < M; j++) work[j] += alloc[i][j];
                finish[i] = 1;
                seq[count++] = i;
                found = 1;
                printf("  B%d can finish -> Work = %d %d %d %d\n", i, work[0], work[1], work[2], work[3]);
            }
        }
        if (!found) {
            printf("  No remaining job can finish -> UNSAFE state\n");
            return 0;
        }
    }
    printf("  SAFE state. Safe sequence: ");
    for (int i = 0; i < N; i++) printf("B%d%s", seq[i], i < N - 1 ? " -> " : "\n");
    return 1;
}

/* try to give job p the resources in req[] */
void request(int p, int req[])
{
    printf("\nRequest from B%d: %d %d %d %d\n", p, req[0], req[1], req[2], req[3]);
    for (int j = 0; j < M; j++) {
        if (req[j] > need[p][j]) { printf("  Error: more than its maximum claim\n"); return; }
        if (req[j] > avail[j])   { printf("  Not enough available -> B%d must wait\n", p); return; }
    }
    /* pretend to allocate */
    for (int j = 0; j < M; j++) { avail[j] -= req[j]; alloc[p][j] += req[j]; need[p][j] -= req[j]; }

    if (is_safe()) {
        printf("  Request GRANTED\n");
    } else {
        for (int j = 0; j < M; j++) { avail[j] += req[j]; alloc[p][j] -= req[j]; need[p][j] += req[j]; }
        printf("  Request DENIED (would be unsafe), B%d must wait\n", p);
    }
}

int main(void)
{
    for (int i = 0; i < N; i++)
        for (int j = 0; j < M; j++)
            need[i][j] = max[i][j] - alloc[i][j];

    printf("Job   Allocation   Max        Need\n");
    printf("      E P C T      E P C T    E P C T\n");
    for (int i = 0; i < N; i++)
        printf("B%d    %d %d %d %d      %d %d %d %d    %d %d %d %d\n", i,
               alloc[i][0], alloc[i][1], alloc[i][2], alloc[i][3],
               max[i][0], max[i][1], max[i][2], max[i][3],
               need[i][0], need[i][1], need[i][2], need[i][3]);
    printf("Available: %d %d %d %d\n", avail[0], avail[1], avail[2], avail[3]);

    printf("\nSafety check of the current state:\n");
    is_safe();

    int r1[M] = {1, 0, 2, 0};   /* B1 asks for 1 electrician and 2 cleaners */
    request(1, r1);

    int r2[M] = {0, 2, 0, 0};   /* B0 asks for 2 plumbers */
    request(0, r2);
    return 0;
}
