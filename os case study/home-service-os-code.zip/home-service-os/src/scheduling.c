/*
 * Module 2: CPU Scheduling of service requests
 * FCFS and Round Robin. Prints waiting time, turnaround time and a Gantt chart.
 *   Turnaround time = Completion time - Arrival time
 *   Waiting time    = Turnaround time - Burst time
 * Requests are listed in order of arrival.
 */
#include <stdio.h>

#define N 5

const char *name[N] = {"Electrician", "Plumber", "Cleaner", "Appliance Repair", "Payment"};
int arrival[N] = {0, 1, 2, 3, 4};
int burst[N]   = {5, 3, 8, 6, 2};

/* Gantt chart: which request ran from gstart[k] to gend[k] */
int gid[50], gstart[50], gend[50], gcount;

void add_gantt(int id, int s, int e)
{
    gid[gcount] = id;
    gstart[gcount] = s;
    gend[gcount] = e;
    gcount++;
}

void print_results(const char *title, int completion[])
{
    float total_wt = 0, total_tat = 0;
    printf("\n%s\n", title);
    printf("Req  Service           AT  BT  CT  TAT  WT\n");
    for (int i = 0; i < N; i++) {
        int tat = completion[i] - arrival[i];
        int wt = tat - burst[i];
        total_tat += tat;
        total_wt += wt;
        printf("R%-3d %-17s %2d  %2d  %2d  %3d  %2d\n",
               i + 1, name[i], arrival[i], burst[i], completion[i], tat, wt);
    }
    printf("Average turnaround time = %.2f\n", total_tat / N);
    printf("Average waiting time    = %.2f\n", total_wt / N);

    printf("Gantt chart:\n");
    for (int k = 0; k < gcount; k++) printf("|  R%d  ", gid[k]);
    printf("|\n");
    for (int k = 0; k < gcount; k++) printf("%-7d", gstart[k]);
    printf("%d\n", gend[gcount - 1]);
}

void fcfs(void)
{
    int completion[N], time = 0;
    gcount = 0;
    for (int i = 0; i < N; i++) {
        if (time < arrival[i]) time = arrival[i];   /* CPU idle until it arrives */
        add_gantt(i + 1, time, time + burst[i]);
        time += burst[i];
        completion[i] = time;
    }
    print_results("FCFS (First Come First Served)", completion);
}

void round_robin(int quantum)
{
    int remaining[N], completion[N];
    int queue[100], front = 0, rear = 0;
    int time = 0, done = 0, next = 0;   /* next = first request not yet in the queue */
    gcount = 0;

    for (int i = 0; i < N; i++) remaining[i] = burst[i];

    while (done < N) {
        while (next < N && arrival[next] <= time) queue[rear++] = next++;
        if (front == rear) { time = arrival[next]; continue; }   /* nothing ready */

        int i = queue[front++];
        int run = remaining[i] < quantum ? remaining[i] : quantum;

        /* merge with the previous slot if the same request keeps running */
        if (gcount > 0 && gid[gcount - 1] == i + 1) gend[gcount - 1] += run;
        else add_gantt(i + 1, time, time + run);

        time += run;
        remaining[i] -= run;

        /* new arrivals join the queue before the preempted request */
        while (next < N && arrival[next] <= time) queue[rear++] = next++;

        if (remaining[i] > 0) queue[rear++] = i;
        else { completion[i] = time; done++; }
    }
    char title[50];
    sprintf(title, "Round Robin (time quantum = %d)", quantum);
    print_results(title, completion);
}

int main(void)
{
    fcfs();
    round_robin(2);
    return 0;
}
