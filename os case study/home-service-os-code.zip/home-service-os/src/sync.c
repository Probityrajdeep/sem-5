/*
 * Module 3: Synchronization
 * Part 1: Race condition - 5 customers book the same electrician at once.
 * Part 2: Fix with a mutex.
 * Part 3: Counting semaphore - 6 customers share a pool of 3 plumbers.
 */
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/time.h>

#define CUSTOMERS 5

int provider_free = 1;        /* 1 = electrician Ravi is free */
int bookings = 0;             /* how many customers were confirmed */
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

/* ---------- Part 1: no synchronization ---------- */
void *book_without_lock(void *arg)
{
    int id = *(int *)arg;
    if (provider_free) {               /* check ...                     */
        usleep(1000);                  /* ... delay (saving to database) */
        provider_free = 0;             /* ... then book                 */
        bookings++;
        printf("Customer %d: booked Ravi\n", id);
    } else {
        printf("Customer %d: Ravi is busy\n", id);
    }
    return NULL;
}

/* ---------- Part 2: mutex ---------- */
void *book_with_mutex(void *arg)
{
    int id = *(int *)arg;
    pthread_mutex_lock(&lock);         /* only one customer at a time */
    if (provider_free) {
        usleep(1000);
        provider_free = 0;
        bookings++;
        printf("Customer %d: booked Ravi\n", id);
    } else {
        printf("Customer %d: Ravi is busy\n", id);
    }
    pthread_mutex_unlock(&lock);
    return NULL;
}

void run_booking(void *(*fn)(void *))
{
    pthread_t t[CUSTOMERS];
    int id[CUSTOMERS];
    provider_free = 1;
    bookings = 0;
    for (int i = 0; i < CUSTOMERS; i++) {
        id[i] = i + 1;
        pthread_create(&t[i], NULL, fn, &id[i]);
    }
    for (int i = 0; i < CUSTOMERS; i++) pthread_join(t[i], NULL);
    printf("Customers confirmed for ONE electrician: %d\n", bookings);
}

/* ---------- Part 3: counting semaphore ---------- */
#define PLUMBERS 3
#define WAITING_CUSTOMERS 6

sem_t plumbers;
int busy = 0;                 /* plumbers currently working */
double start;

double now_ms(void)
{
    struct timeval t;
    gettimeofday(&t, NULL);
    return t.tv_sec * 1000.0 + t.tv_usec / 1000.0;
}

void *need_plumber(void *arg)
{
    int id = *(int *)arg;
    sem_wait(&plumbers);               /* wait for a free plumber */

    pthread_mutex_lock(&lock);
    busy++;
    printf("[%3.0f ms] Customer %d gets a plumber (busy plumbers: %d)\n", now_ms() - start, id, busy);
    pthread_mutex_unlock(&lock);

    usleep(100 * 1000);                /* the job takes 100 ms */

    pthread_mutex_lock(&lock);
    busy--;
    printf("[%3.0f ms] Customer %d done, plumber released\n", now_ms() - start, id);
    pthread_mutex_unlock(&lock);

    sem_post(&plumbers);               /* plumber is free again */
    return NULL;
}

int main(void)
{
    printf("--- Part 1: Race condition (no lock) ---\n");
    run_booking(book_without_lock);

    printf("\n--- Part 2: With mutex ---\n");
    run_booking(book_with_mutex);

    printf("\n--- Part 3: Semaphore (%d plumbers, %d customers) ---\n", PLUMBERS, WAITING_CUSTOMERS);
    pthread_t t[WAITING_CUSTOMERS];
    int id[WAITING_CUSTOMERS];
    sem_init(&plumbers, 0, PLUMBERS);
    start = now_ms();
    for (int i = 0; i < WAITING_CUSTOMERS; i++) {
        id[i] = i + 1;
        pthread_create(&t[i], NULL, need_plumber, &id[i]);
    }
    for (int i = 0; i < WAITING_CUSTOMERS; i++) pthread_join(t[i], NULL);
    sem_destroy(&plumbers);
    return 0;
}
