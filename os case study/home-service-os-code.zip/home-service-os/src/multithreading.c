/*
 * Module 1: Multithreading
 * Each customer is a thread that requests a home service.
 * Handling one request takes 500 ms (finding a provider, confirming the slot).
 * We serve 5 customers sequentially, then with one thread per customer,
 * and compare the total time.
 */
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>

#define N 5

const char *service[N] = {"Electrician", "Plumber", "Cleaner", "Appliance Repair", "Electrician"};
double start_time;

double now_ms(void)
{
    struct timeval t;
    gettimeofday(&t, NULL);
    return t.tv_sec * 1000.0 + t.tv_usec / 1000.0;
}

void *handle_request(void *arg)
{
    int id = *(int *)arg;
    double s = now_ms() - start_time;
    usleep(500 * 1000);                     /* processing the request */
    double e = now_ms() - start_time;
    printf("Customer %d (%s): start %.0f ms, end %.0f ms\n", id, service[id - 1], s, e);
    return NULL;
}

int main(void)
{
    pthread_t tid[N];
    int id[N];

    /* sequential: one customer after another */
    printf("--- Sequential execution ---\n");
    start_time = now_ms();
    for (int i = 0; i < N; i++) {
        id[i] = i + 1;
        handle_request(&id[i]);
    }
    double seq = now_ms() - start_time;
    printf("Total time (sequential): %.0f ms\n\n", seq);

    /* multithreaded: one thread per customer */
    printf("--- Multithreaded execution ---\n");
    start_time = now_ms();
    for (int i = 0; i < N; i++)
        pthread_create(&tid[i], NULL, handle_request, &id[i]);
    for (int i = 0; i < N; i++)
        pthread_join(tid[i], NULL);
    double par = now_ms() - start_time;
    printf("Total time (multithreaded): %.0f ms\n\n", par);

    printf("Speedup = %.0f / %.0f = %.2fx\n", seq, par, seq / par);
    return 0;
}
